import React from 'react';
import { Container } from 'react-bootstrap';
import "./style/Analysis.css";

function Analysis() {
  return (
    <Container className='analysis-container'>
        <Container className='analysis-innerContainer'>
            <h1>Assessment Results</h1>
        </Container>
    </Container>
  )
}

export default Analysis;