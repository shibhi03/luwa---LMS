import React from 'react'
import { Bar, Pie } from 'react-chartjs-2'

function Chart() {
    
}

export default Chart